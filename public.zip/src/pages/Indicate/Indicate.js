import React from 'react'

const Indicate = () => {
  return (
    <div>
      Indicate
    </div>
  )
}

export default Indicate
